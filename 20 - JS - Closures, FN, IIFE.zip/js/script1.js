/*
var name = "Yaakov";
function sayHello()
{
	console.log("Hello " + name);
}
*/

/* fake namespaces */
var yaakovGreeter = 
{
	name: "Yaakov",
	sayHello: function () {console.log("Hello " + yaakovGreeter.name);}
}
