/* immediatly invoked function expression (IIFE) */
(function(name)
{
	console.log("Hello " + name);
})("world!"); // we are passing a parameter to our IIFE

//a();

/*
sayHello();
sayHi();
*/

/* fake namespaces */
yaakovGreeter.sayHello();
johnGreeter.sayHi();

console.log(yaakovGreeter.name);