/*
var name = "John";
function sayHi()
{
	console.log("Hi " + name);
}
*/

var johnGreeter = {}; //empty object

// we are populating the object
johnGreeter.name = "John";
johnGreeter.sayHi = function () {console.log("Hi " + johnGreeter.name);}