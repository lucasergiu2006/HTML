function start()
{
	alert("Hello, let`s play a game. Guess what number I am thinking of, ranged 0 to 100\n");
	input();
}
function input()
{
	// Math.random() return a number in [0,1)
	var generated_no = Math.floor(Math.random() * 101);
	console.log(generated_no);
	var guess = parseInt(prompt("Please enter a number from 0 to 100\n"));
	while ((isNaN(guess) == 1) || (guess < 0) || (guess > 100)) //isNotaNumber
	{
		guess = parseInt(prompt("Please enter a number from 0 to 100\n"));
	}
	match(generated_no, guess);
}
function match(a,b)
{
	var count = 1;
	console.log(a,b);
	if (a == b)
	{
		alert("You guessed by " + count + " try");
	}
	else 
	{
		while(a != b )
		{
			if((isNaN(b) == 0) && (b > 0) && (b < 101) && (a != b))
			{
				if (a > b)
					alert("Go higher\n");
				else
					alert("Go lower\n");
			}
			b = parseInt(prompt("Please enter a number from 0 to 100\n"));
			count++;
			if((isNaN(b) == 1) || (b < 0) || (b > 100))
			{
				b = parseInt(prompt("Please enter a number from 0 to 100\n"));
			}
		}
		alert("You guessed by " + count + " tries");
	}
}
