// Declaratii variabile globale
var colors = new Array(6);
colors[0] = "alb";
colors[1] = "bej";
colors[2] = "galben";
colors[3] = "gri";
colors[4] = "rooza";
colors[5] = "roozb";
colors[6] = "verde";


// functiile scriptului
function start()
{
	alert("Din lista de culori afisata, ghiceste culoarea\n alb\n bej\n galben\n gri\n rooza\n roozb\n verde\n");
	input();
}


function input()
{	
	var random_color_index = Math.floor(Math.random() * 7);
	var random_color = colors[random_color_index];
	alert("Culoarea generata este " + random_color); 
	var pick_color = prompt("Alege culoarea\n alb\n bej\n galben\n gri\n rooza\n roozb\n verde\n");
	while(inArray(pick_color) == 0)
	{
		pick_color = prompt("Alege culoarea\n alb\n bej\n galben\n gri\n rooza\n roozb\n verde\n");
	}
	match(random_color, pick_color);
}


function inArray(a)
{
	var i;
	for(i = 0; i < 7; i++)
		if( colors[i] == a)
			return 1;
	return 0;
}


function match(r,p)
{
	console.log(r,p);
	var flag = 0;
	if(r == p)
	{
		alert("Ai ghicit din prima incercare!");
		change_background_color(r);
		flag = 1;
	}
	else
		while(r != p)
		{   
			//string.charAt(index); inde = Required. An integer representing the index of the character you want to return
			var first_letter_r = String(r).charAt(0);
			var first_letter_p = String(p).charAt(0);
			// difera prima litera 
			if(first_letter_r != first_letter_p)
			{
				if(first_letter_p < first_letter_r)
					p = prompt("Culoarea este mai sus alfabetic. Mai incearca\n alb\n bej\n galben\n gri\n rooza\n roozb\n verde\n");
				else
					p = prompt("Culoarea este mai jos alfabetic. Mai incearca\n alb\n bej\n galben\n gri\n rooza\n roozb\n verde\n");
			}
			// prima litera identica, dar diferite culorile
			if ((first_letter_r == first_letter_p) && (r != p))
			{
			    further_check(r, p);
				p = prompt("Mai introdu odata culoarea\n alb\n bej\n galben\n gri\n rooza\n roozb\n verde\n");
			}
		}
		if( flag == 0)
		{
			alert("Ai ghicit");
			change_background_color(r);
		}
}


function further_check(r,p)
{
	var x = String(r).charAt(0);
	var	y = String(p).charAt(0);
	if (x == y)
	{
		r_partial = String(r).substr(1);
		p_partial = String(p).substr(1);
		// functia se apeleaza recursiv
		further_check(r_partial, p_partial);
	}
	else
	{
		if(y < x)
			alert("Culoarea este mai sus alfabetic. Mai incearca\n alb\n bej\n galben\n gri\n rooza\n roozb\n verde\n");
		else
			alert("Culoarea este mai jos alfabetic. Mai incearca\n alb\n bej\n galben\n gri\n rooza\n roozb\n verde\n"); 
	}
}


function change_background_color(r)
{
	console.log(r);
	if (r == "alb")
		document.body.style.backgroundColor = "#FFFFFF";
	if (r == "bej") 
		document.body.style.backgroundColor = "#DAA520";
	if (r == "galben") 
		document.body.style.backgroundColor = "#FFFF00";
	if (r == "gri") 
		document.body.style.backgroundColor = "	#808080";
	if (r == "rooza") 
		document.body.style.backgroundColor = "#FF1493";
	if (r == "roozb") 
		document.body.style.backgroundColor = "#FF69B4";
	if (r == "verde") 
		document.body.style.backgroundColor = "	#7FFF00";
}
